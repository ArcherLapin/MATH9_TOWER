"""
TOWER DEFENSE DESIGNER  -  Math 9 (Mr. Chung)
=============================================
Build a level on the Day 1 map, then watch a monster walk the road and see
the total damage T add up, one tile per second.

Run on a computer:     pip install pygame-ce      then   python main.py
Run in a browser:      pip install pygbag         then   pygbag game_folder
                       (this file must be named main.py inside that folder)

Controls
  Tools (top bar or keys):  R = Road   A = Arrow   C = Cannon   M = Mage   F = Frost   E = Erase
  Road: click a tile in column 1, then click or drag tile by tile, then click the
        castle to connect. The road may pass beside the castle without connecting.
        The road may cross or run back over itself: those tiles are hit again.
        Click the last road tile (or drag back over it) to undo it.
  Frost (Day 3): 1 Frost tower. Every road tile in its 5 x 5 box gets one extra hit.
  Right-click anything = erase it (erasing a road tile cuts the road from there;
        right-clicking the castle disconnects the road).
  Left / Right keys = change power x      Space = start / stop the battle
  T = tag table                            Esc = close the tag table
"""

import asyncio
from fractions import Fraction

import pygame

# --------------------------------------------------------------------------
# The map (taken from the Day 1 "Build Your Level" page)
# --------------------------------------------------------------------------
COLS, ROWS = 24, 17
ROCKS = {
    (4, 1), (5, 1), (11, 1), (12, 1), (18, 1), (21, 1),
    (12, 2), (21, 2),
    (15, 3),
    (7, 4), (8, 4),
    (7, 5), (18, 5),
    (18, 6),
    (10, 7),
    (5, 8), (19, 8),
    (16, 9),
    (12, 10),
    (4, 11), (18, 11),
    (4, 12), (13, 12), (14, 12),
    (13, 13), (14, 13), (20, 13), (21, 13),
    (8, 14), (20, 14),
    (10, 15), (11, 15),
    (6, 16), (16, 16),
    (3, 17), (6, 17), (9, 17), (15, 17), (16, 17), (20, 17), (22, 17),
}
CASTLE = {(c, r) for c in (23, 24) for r in (8, 9, 10)}

TOWERS = {
    "A": {"name": "Arrow", "coef": Fraction(1), "const": Fraction(10),
          "color": (30, 150, 128), "expr": "x + 10"},
    "C": {"name": "Cannon", "coef": Fraction(2), "const": Fraction(0),
          "color": (226, 92, 52), "expr": "2x"},
    "M": {"name": "Mage", "coef": Fraction(1, 2), "const": Fraction(15),
          "color": (132, 92, 206), "expr": "0.5x + 15"},
}
ORDER = "ACM"
MAX_PER_TYPE = None                 # no limit on towers per type (set to 3 to bring the Day 1 limit back)
FROST_COLOR = (52, 150, 210)        # Frost: no damage of its own, 1 extra hit on every tile in its box

MONSTERS = [
    {"key": "slime", "name": "Slime", "desc": "1500 HP. No armour: takes T.",
     "hp": lambda x: Fraction(1500), "factor": Fraction(1)},
    {"key": "knight", "name": "Armoured Knight", "desc": "1260 HP. Armour blocks 30%: takes 0.7T.",
     "hp": lambda x: Fraction(1260), "factor": Fraction(7, 10)},
    {"key": "bats", "name": "Bat Swarm", "desc": "375 HP each. 3 bats share every hit: T ÷ 3.",
     "hp": lambda x: Fraction(375), "factor": Fraction(1, 3)},
    {"key": "mimic", "name": "Mimic", "desc": "HP = 10x + 1500. Copies your power. Takes T.",
     "hp": lambda x: 10 * x + 1500, "factor": Fraction(1)},
    {"key": "dummy", "name": "Training Dummy", "desc": "No HP. Just measures the total damage.",
     "hp": None, "factor": Fraction(1)},
]

# Sam Rivera's sample level from the teacher copy (T = 63x + 310).
# Day 3: Frost at column 7, row 8 gives Extra = 27.5x + 105.
SAMPLE_ROAD = ([(c, 6) for c in range(1, 10)] + [(9, r) for r in range(7, 12)]
               + [(c, 11) for c in range(10, 18)] + [(17, 10), (17, 9)]
               + [(c, 9) for c in range(18, 23)])
SAMPLE_TOWERS = {(2, 5): ("A", 1), (20, 7): ("A", 2), (15, 9): ("A", 3),
                 (9, 5): ("C", 1), (10, 9): ("C", 2), (11, 9): ("C", 3),
                 (6, 4): ("M", 1), (5, 7): ("M", 2)}
SAMPLE_ENTRY = (23, 9)               # castle tile the sample road enters

# --------------------------------------------------------------------------
# Layout and colours
# --------------------------------------------------------------------------
W, H = 1280, 720
TILE = 34
GX, GY = 30, 82                      # top-left corner of the grid
GRID_W, GRID_H = COLS * TILE, ROWS * TILE
PX, PW = GX + GRID_W + 20, 400       # right-hand panel

BG = (251, 247, 236)
INK = (40, 36, 32)
MUTED = (120, 112, 100)
GRASS = (228, 241, 214)
GRASS_LINE = (198, 220, 180)
START = (246, 234, 168)
ROAD = (236, 200, 152)
ROAD_EDGE = (205, 160, 105)
ROCK = (150, 146, 140)
ROCK_DARK = (95, 92, 88)
GOOD = (40, 160, 90)
BAD = (215, 60, 50)
WARN = (230, 150, 40)
PANEL = (255, 253, 247)
HEADER = (255, 214, 92)


def frac_str(v):
    """Number to at most 2 decimals, no trailing zeros."""
    r = round(float(v), 2)
    if abs(r - round(r)) < 1e-9:
        return str(int(round(r)))
    return f"{r:.2f}".rstrip("0").rstrip(".")


def expr_str(coef, const):
    parts = []
    if coef != 0:
        parts.append("x" if coef == 1 else f"{frac_str(coef)}x")
    if const != 0 or not parts:
        parts.append(frac_str(const))
    return " + ".join(parts)


def neighbours(t):
    c, r = t
    return [(c + 1, r), (c - 1, r), (c, r + 1), (c, r - 1)]


def adjacent(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1]) == 1


def in_grid(t):
    return 1 <= t[0] <= COLS and 1 <= t[1] <= ROWS


def tile_rect(t):
    return pygame.Rect(GX + (t[0] - 1) * TILE, GY + (t[1] - 1) * TILE, TILE, TILE)


def tile_center(t):
    return (GX + (t[0] - 0.5) * TILE, GY + (t[1] - 0.5) * TILE)


def dashed_rect(surf, color, rect, width=2, dash=6):
    x0, y0, x1, y1 = rect.left, rect.top, rect.right - 1, rect.bottom - 1
    for x in range(x0, x1, dash * 2):
        pygame.draw.line(surf, color, (x, y0), (min(x + dash, x1), y0), width)
        pygame.draw.line(surf, color, (x, y1), (min(x + dash, x1), y1), width)
    for y in range(y0, y1, dash * 2):
        pygame.draw.line(surf, color, (x0, y), (x0, min(y + dash, y1)), width)
        pygame.draw.line(surf, color, (x1, y), (x1, min(y + dash, y1)), width)


def draw_star(surf, color, center, r):
    import math
    cx, cy = center
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rad = r if i % 2 == 0 else r * 0.45
        pts.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
    pygame.draw.polygon(surf, color, pts)


def each_str(tag):
    """Each tower's damage on one tile, e.g. (x + 10) + 2x. Long tags are grouped: 3(x + 10) + 2(2x)."""
    if len(tag) <= 3:
        return " + ".join(f"({TOWERS[k]['expr']})" if "+" in TOWERS[k]["expr"] else TOWERS[k]["expr"]
                          for k in tag)
    parts = []
    for k in ORDER:
        n = tag.count(k)
        if n:
            e = TOWERS[k]["expr"]
            parts.append(e if n == 1 and "+" not in e else f"({e})" if n == 1 else f"{n}({e})")
    return " + ".join(parts)


def short_tag(tag):
    """AAACMMMM -> 3A C 4M, so a long tag still fits on a tile."""
    return " ".join(f"{tag.count(k)}{k}" if tag.count(k) > 1 else k for k in ORDER if k in tag)


def in_box(center, t):
    """True if tile t is inside the 5 x 5 box around center."""
    return abs(center[0] - t[0]) <= 2 and abs(center[1] - t[1]) <= 2


class Button:
    def __init__(self, rect, label, action, active=None, color=None, font="m"):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.action = action
        self.active = active or (lambda: False)
        self.color = color
        self.font = font


# --------------------------------------------------------------------------
# The game
# --------------------------------------------------------------------------
class Game:
    def __init__(self):
        self.fonts = {
            "xs": pygame.font.Font(None, 17),
            "s": pygame.font.Font(None, 20),
            "m": pygame.font.Font(None, 24),
            "l": pygame.font.Font(None, 30),
            "xl": pygame.font.Font(None, 44),
            "tag": pygame.font.Font(None, 18),
            "tiny": pygame.font.Font(None, 15),
        }
        self.road = []                 # ordered list of (col, row); a tile may appear twice (overlap)
        self.road_closed = False       # True once the road is connected to the castle
        self.castle_entry = None       # castle tile the road enters
        self.towers = {}               # (col, row) -> (type, number)
        self.frost = None              # (col, row) of the Frost tower, or None
        self.tool = "road"
        self.show_boxes = True
        self.show_math = True
        self.show_table = False
        self.power = 20
        self.monster_i = 0
        self.speed = 1
        self.battle = None
        self.effects = []              # shot lines and floating numbers
        self.message = "Start with the Road tool: click a tile in column 1."
        self.msg_color = INK
        self.dragging = False
        self.drag_last = None
        self.slider_drag = False
        self.hover = None
        self.analysis = None
        self.build_buttons()
        self.reanalyze()

    # ---------------- buttons ----------------
    def build_buttons(self):
        b = []
        x = 300
        for key, label, col in [("road", "Road", ROAD_EDGE), ("A", "Arrow", TOWERS["A"]["color"]),
                                ("C", "Cannon", TOWERS["C"]["color"]), ("M", "Mage", TOWERS["M"]["color"]),
                                ("F", "Frost", FROST_COLOR), ("erase", "Erase", (110, 110, 110))]:
            b.append(Button((x, 18, 84, 40), label, lambda k=key: self.set_tool(k),
                            active=lambda k=key: self.tool == k, color=col))
            x += 90
        x = PX
        for label, act, active in [("Sample", self.load_sample, None),
                                   ("Clear", self.clear_all, None),
                                   ("Boxes", self.toggle_boxes, lambda: self.show_boxes),
                                   ("Tags & T", self.toggle_math, lambda: self.show_math),
                                   ("Tag table", self.toggle_table, lambda: self.show_table)]:
            b.append(Button((x, 18, 76, 40), label, act, active=active, font="s"))
            x += 81
        # battle controls
        y = 362
        b.append(Button((PX + 80, y, 34, 30), "-", lambda: self.change_power(-1)))
        b.append(Button((PX + 330, y, 34, 30), "+", lambda: self.change_power(1)))
        y = 404
        b.append(Button((PX + 80, y, 34, 30), "<", lambda: self.change_monster(-1)))
        b.append(Button((PX + 330, y, 34, 30), ">", lambda: self.change_monster(1)))
        y = 466
        for i, s in enumerate((1, 2, 4)):
            b.append(Button((PX + 80 + i * 50, y, 44, 30), f"{s}x", lambda s=s: self.set_speed(s),
                            active=lambda s=s: self.speed == s, font="s"))
        b.append(Button((PX + 240, y - 2, 124, 34), "Start battle", self.toggle_battle,
                        active=lambda: self.battle is not None and self.battle["result"] is None,
                        color=GOOD))
        self.buttons = b
        self.slider = pygame.Rect(PX + 124, 374, 196, 6)  # power slider track

    def say(self, text, color=INK):
        self.message, self.msg_color = text, color

    def set_tool(self, k):
        self.tool = k
        hints = {"road": "Road: start in column 1, click or drag tile by tile, then click the castle.",
                 "A": "Arrow tower (x + 10): click a grass tile beside the road.",
                 "C": "Cannon tower (2x): click a grass tile beside the road.",
                 "M": "Mage tower (0.5x + 15): click a grass tile beside the road.",
                 "F": "Frost: click a grass tile. Road tiles in its box get 1 extra hit. Click again to move it.",
                 "erase": "Erase: click a tower to remove it, or a road tile to cut the road from there."}
        self.say(hints[k])

    def toggle_boxes(self):
        self.show_boxes = not self.show_boxes

    def toggle_math(self):
        self.show_math = not self.show_math
        if not self.show_math:
            self.show_table = False
        self.say("Tags and T are shown." if self.show_math else
                 "Tags and T are hidden until the battle ends. Work them out on paper first!")

    def toggle_table(self):
        if not self.show_math:
            self.say("Turn on 'Tags & T' to see the tag table.", WARN)
            return
        self.show_table = not self.show_table

    def set_speed(self, s):
        self.speed = s

    def change_power(self, d):
        if self.battle_running():
            return
        self.power = max(0, min(100, self.power + d))

    def change_monster(self, d):
        if self.battle_running():
            return
        self.monster_i = (self.monster_i + d) % len(MONSTERS)
        self.battle = None

    def load_sample(self):
        self.battle = None
        self.road = list(SAMPLE_ROAD)
        self.road_closed, self.castle_entry = True, SAMPLE_ENTRY
        self.towers = dict(SAMPLE_TOWERS)
        self.frost = None
        self.reanalyze()
        self.say("Loaded the sample level (Cannon Corner). T = 63x + 310. Day 3: try Frost at column 7, row 8.")

    def clear_all(self):
        self.battle = None
        self.road, self.towers = [], {}
        self.road_closed, self.castle_entry = False, None
        self.frost = None
        self.reanalyze()
        self.say("Cleared. Start with the Road tool: click a tile in column 1.")

    # ---------------- rules ----------------
    def road_complete(self):
        return bool(self.road) and self.road_closed

    def touches_castle(self):
        """The last road tile is next to the castle (but not necessarily connected)."""
        return bool(self.road) and any(n in CASTLE for n in neighbours(self.road[-1]))

    def road_path(self):
        """The road as walked, including the castle tile it enters once connected."""
        return self.road + ([self.castle_entry] if self.road_closed else [])

    def disconnect_castle(self):
        self.road_closed, self.castle_entry = False, None

    def undo_last_road(self):
        """Step the road back by one: first the castle connection, then the last tile."""
        if self.road_closed:
            self.disconnect_castle()
            msg = "Disconnected from the castle."
        else:
            self.road.pop()
            msg = f"Undid the last road tile. Road: {len(self.road)} tiles."
        self.battle = None
        self.reanalyze()
        self.say(msg)

    def try_add_road(self, t):
        if not in_grid(t):
            return False
        if self.road_closed:
            self.say("The road already reaches the castle. Click the castle or use Erase to change it.", WARN)
            return False
        if t in CASTLE:
            if not self.road:
                self.say("Start the road in column 1 (the yellow strip on the left).", BAD)
                return False
            if not adjacent(t, self.road[-1]):
                if not self.touches_castle():
                    self.say("The last road tile must touch the castle before you can connect it.", BAD)
                    return False
                t = next(n for n in neighbours(self.road[-1]) if n in CASTLE)   # any castle click works
            self.road_closed, self.castle_entry = True, t
            self.battle = None
            self.reanalyze()
            self.say(f"Road finished: {len(self.road)} tiles. Now place 6 to 9 towers beside it.", GOOD)
            return True
        if t in ROCKS:
            self.say("Rocks block the road. Go around them.", BAD)
            return False
        if t in self.towers or t == self.frost:
            self.say("A tower is on that tile. Roads and towers can't share a tile.", BAD)
            return False
        if not self.road:
            if t[0] != 1:
                self.say("Start the road in column 1 (the yellow strip on the left).", BAD)
                return False
        else:
            if not adjacent(t, self.road[-1]):
                self.say("Road tiles must join side to side (no diagonals, no gaps).", BAD)
                return False
            if len(self.road) >= 2 and t == self.road[-2]:
                self.say("The road can't turn straight back. (Click the last tile to undo it.)", WARN)
                return False
        overlap = t in self.road
        self.road.append(t)
        self.battle = None
        self.reanalyze()
        if overlap:
            n = self.road.count(t)
            self.say(f"Overlap! The road uses tile ({t[0]}, {t[1]}) {n} times, so it is hit {n} times.", WARN)
        elif self.touches_castle():
            self.say(f"Road: {len(self.road)} tiles. It touches the castle: click the castle to connect, "
                     f"or keep going.")
        else:
            self.say(f"Road: {len(self.road)} tiles. Keep going to the castle.")
        return True

    def place_tower(self, t, kind):
        name = TOWERS[kind]["name"]
        if t in ROCKS or t in CASTLE:
            self.say("Towers go on grass tiles, not rocks or the castle.", BAD)
            return
        if t in self.road:
            self.say("Towers can't go on the road. Put it beside the road.", BAD)
            return
        if t in self.towers or t == self.frost:
            self.say("There is already a tower there. Erase it first.", BAD)
            return
        used = {n for (k, n) in self.towers.values() if k == kind}
        if MAX_PER_TYPE and len(used) >= MAX_PER_TYPE:
            self.say(f"You already have {MAX_PER_TYPE} {name} towers (the most allowed).", BAD)
            return
        num = 1
        while num in used:                      # lowest free number: A1, A2, ... A10, ...
            num += 1
        self.towers[t] = (kind, num)
        self.battle = None
        self.reanalyze()
        self.say(f"Placed {kind}{num}. Its 5 × 5 box hits every road tile inside it.")

    def place_frost(self, t):
        if t in ROCKS or t in CASTLE:
            self.say("Towers go on grass tiles, not rocks or the castle.", BAD)
            return
        if t in self.road:
            self.say("Towers can't go on the road. Put it beside the road.", BAD)
            return
        if t in self.towers:
            self.say("There is already a tower there. Erase it first.", BAD)
            return
        if t == self.frost:
            return
        moved = self.frost is not None
        self.frost = t
        self.battle = None
        self.reanalyze()
        stars = sum(1 for info in self.analysis["tiles"] if info["frost"])
        self.say(f"{'Moved' if moved else 'Placed'} F. {stars} road tile{'s' if stars != 1 else ''} "
                 f"in its box get 1 extra hit (stars).")

    def erase(self, t):
        if t in self.towers:
            k, n = self.towers.pop(t)
            self.say(f"Removed {k}{n}.")
        elif t == self.frost:
            self.frost = None
            self.say("Removed F.")
        elif t in CASTLE:
            if not self.road_closed:
                return
            self.disconnect_castle()
            self.say("Disconnected the road from the castle.")
        elif t in self.road:
            # cut at the LAST time the road uses this tile, so an overlap only loses the later pass
            i = len(self.road) - 1 - self.road[::-1].index(t)
            cut = len(self.road) - i
            self.road = self.road[:i]
            self.disconnect_castle()
            self.say(f"Cut {cut} road tile{'s' if cut != 1 else ''}.")
        else:
            return
        self.battle = None
        self.reanalyze()

    def covering(self, t):
        """Towers whose 5 x 5 box covers tile t, in A, C, M order."""
        hits = [(k, n, pos) for pos, (k, n) in self.towers.items() if in_box(pos, t)]
        hits.sort(key=lambda h: (ORDER.index(h[0]), h[1]))
        return hits

    def reanalyze(self):
        tiles = []
        T_coef, T_const = Fraction(0), Fraction(0)      # Day 2 total (no Frost)
        E_coef, E_const = Fraction(0), Fraction(0)      # Frost extra damage
        table = {}                      # tag -> row, in order of first appearance
        frost_table = {}                # tag on a star tile -> row
        too_many = set()
        # Each time the monster steps on a tile counts, so an overlapped tile is hit twice.
        for t in self.road:
            hits = self.covering(t)
            tag = "".join(h[0] for h in hits)
            coef = sum((TOWERS[h[0]]["coef"] for h in hits), Fraction(0))
            const = sum((TOWERS[h[0]]["const"] for h in hits), Fraction(0))
            frost = self.frost is not None and in_box(self.frost, t)
            tiles.append({"tile": t, "hits": hits, "tag": tag, "coef": coef, "const": const,
                          "frost": frost, "mult": 2 if frost else 1})
            T_coef += coef
            T_const += const
            if len(hits) > 3:
                too_many.add(t)
            if tag:
                row = table.setdefault(tag, {"tag": tag, "count": 0, "coef": coef, "const": const,
                                             "each": each_str(tag)})
                row["count"] += 1
                if frost:
                    E_coef += coef
                    E_const += const
                    frow = frost_table.setdefault(tag, {"tag": tag, "count": 0, "coef": coef, "const": const})
                    frow["count"] += 1
        counts = {k: sum(1 for (kk, _) in self.towers.values() if kk == k) for k in ORDER}
        overlaps = [tag for tag in table if len(tag) >= 2]
        same = any(len(set(tag)) < len(tag) for tag in overlaps)
        three = any(len(tag) >= 3 for tag in overlaps)
        n = len(overlaps)
        if n >= 8 and same and three:
            level = "Extending"
        elif n >= 5 and same and three:
            level = "Proficient"
        elif n >= 3:
            level = "Developing"
        else:
            level = "Emerging"
        visits = {}
        for t in self.road:
            visits[t] = visits.get(t, 0) + 1
        self.analysis = {"tiles": tiles, "T": (T_coef, T_const), "table": list(table.values()),
                         "extra": (E_coef, E_const), "T_after": (T_coef + E_coef, T_const + E_const),
                         "frost_table": list(frost_table.values()), "visits": visits,
                         "too_many": too_many, "counts": counts, "overlaps": overlaps,
                         "same": same, "three": three, "level": level}

    # ---------------- battle ----------------
    def battle_running(self):
        return self.battle is not None and self.battle["result"] is None

    def toggle_battle(self):
        if self.battle_running():
            self.battle = None
            self.effects = []
            self.say("Battle stopped.")
            return
        if not self.road_complete():
            if self.touches_castle():
                self.say("Your road touches the castle. Click the castle to connect it first.", BAD)
            else:
                self.say("Finish the road to the castle before starting a battle.", BAD)
            return
        if not self.towers:
            self.say("Place some towers first!", BAD)
            return
        m = MONSTERS[self.monster_i]
        x = Fraction(self.power)
        hp = m["hp"](x) if m["hp"] else None
        self.battle = {"idx": -1, "timer": 0.0, "x": x, "monster": m, "hp": hp, "max_hp": hp,
                       "coef": Fraction(0), "const": Fraction(0), "raw": Fraction(0),
                       "result": None, "last": None, "prev_pos": (0.5, self.road[0][1]),
                       "turn": 1}             # turn on the current tile: 1, or 2 when frozen by Frost
        self.effects = []
        self.say(f"Battle! {m['name']} vs your level at power x = {self.power}.")

    def step_battle(self):
        b = self.battle
        tiles = self.analysis["tiles"]
        m, x = b["monster"], b["x"]
        here = tiles[b["idx"]] if b["idx"] >= 0 else None
        if here is not None and here["frost"] and b["turn"] == 1:
            # Frost: after its normal turn here, the monster is frozen and stays 1 more turn; towers hit again
            b["turn"] = 2
            b["prev_pos"] = here["tile"]
        else:
            b["turn"] = 1
            b["prev_pos"] = self.road[b["idx"]] if b["idx"] >= 0 else (0, self.road[0][1])
            b["idx"] += 1
        if b["idx"] >= len(tiles):                       # reached the castle
            Tn = b["raw"]
            if b["hp"] is None:
                b["result"] = "done"
                self.say(f"Done! Total damage T = {expr_str(b['coef'], b['const'])} = {frac_str(Tn)} "
                         f"at power {self.power}.", GOOD)
            else:
                b["result"] = "escaped"
                self.say(f"The {m['name']} reached the castle with {frac_str(b['hp'])} HP left. "
                         f"Power {self.power} is not enough.", BAD)
            return
        info = tiles[b["idx"]]
        dmg = info["coef"] * x + info["const"]           # one turn of hits (a Frost tile gets 2 turns)
        b["coef"] += info["coef"]
        b["const"] += info["const"]
        b["raw"] += dmg
        b["last"] = info
        target = tile_center(info["tile"])
        for k, n, pos in info["hits"]:
            self.effects.append({"kind": "shot", "from": tile_center(pos), "to": target,
                                 "color": TOWERS[k]["color"], "t": 0.0, "life": 0.45})
            one = TOWERS[k]["coef"] * x + TOWERS[k]["const"]
            self.effects.append({"kind": "num", "text": frac_str(one), "pos": target,
                                 "color": TOWERS[k]["color"], "t": 0.0, "life": 0.9,
                                 "dx": (len([e for e in self.effects if e["kind"] == "num"]) % 3 - 1) * 24})
        if b["turn"] == 2:                             # Frost freezes it once: it stays for 1 extra turn
            self.effects.append({"kind": "shot", "from": tile_center(self.frost), "to": target,
                                 "color": FROST_COLOR, "t": 0.0, "life": 0.6})
        if b["hp"] is not None:
            b["hp"] -= m["factor"] * dmg
            if b["hp"] <= 0:
                b["hp"] = Fraction(0)
                b["result"] = "defeated"
                self.say(f"{m['name']} defeated on road tile {b['idx'] + 1} of {len(tiles)} "
                         f"at power {self.power}!", GOOD)

    def update(self, dt):
        for e in self.effects:
            e["t"] += dt
        self.effects = [e for e in self.effects if e["t"] < e["life"]]
        if self.battle_running():
            self.battle["timer"] += dt * self.speed
            while self.battle_running() and self.battle["timer"] >= 1.0:   # 1 move + 1 attack per second
                self.battle["timer"] -= 1.0
                self.step_battle()

    # ---------------- input ----------------
    def grid_tile(self, pos):
        x, y = pos
        if GX <= x < GX + GRID_W and GY <= y < GY + GRID_H:
            return ((x - GX) // TILE + 1, (y - GY) // TILE + 1)
        return None

    def road_drag_to(self, t):
        """Walk from the last dragged tile to t one step at a time (fast drags skip tiles)."""
        if self.road_closed and t in CASTLE:          # wandering around inside the castle
            self.drag_last = t
            return
        cur = self.drag_last
        if self.road_closed and cur in CASTLE:
            cur = self.castle_entry
        while cur != t:
            dc, dr = t[0] - cur[0], t[1] - cur[1]
            if abs(dc) >= abs(dr):
                cur = (cur[0] + (1 if dc > 0 else -1), cur[1])
            else:
                cur = (cur[0], cur[1] + (1 if dr > 0 else -1))
            path = self.road_path()
            if len(path) >= 2 and cur == path[-2]:      # dragged back: undo one step
                self.undo_last_road()
            elif self.road_closed and cur in CASTLE:
                continue
            elif not self.try_add_road(cur):           # new tile, overlap, or connect to the castle
                path = self.road_path()
                self.drag_last = path[-1] if path else None
                if not path:
                    self.dragging = False
                return
        self.drag_last = t

    def click_grid(self, t, button):
        if self.battle_running():
            self.say("Stop the battle to change your level.", WARN)
            return
        if button == 3 or self.tool == "erase":
            self.erase(t)
            return
        if self.tool == "road":
            if t in CASTLE:
                if self.road_closed:
                    self.undo_last_road()               # click the castle again to disconnect
                else:
                    self.try_add_road(t)                # connect (only if the last tile touches it)
            elif self.road and t == self.road[-1] and not self.road_closed:
                self.undo_last_road()
                self.dragging, self.drag_last = True, t
            elif t in self.road and not (self.road and adjacent(t, self.road[-1]) and not self.road_closed):
                self.say("To change the middle of the road, use Erase to cut it there.", WARN)
            elif self.try_add_road(t):                  # a new tile, or an overlap next to the last tile
                self.dragging, self.drag_last = True, t
        elif self.tool == "F":
            self.place_frost(t)
        else:
            self.place_tower(t, self.tool)

    def set_power_from_slider(self, x):
        if self.battle_running():
            return
        f = (x - self.slider.left) / self.slider.width
        self.power = max(0, min(100, round(f * 100)))

    def handle(self, ev):
        if ev.type == pygame.MOUSEBUTTONDOWN and ev.button in (1, 3):
            if ev.button == 1:
                for btn in self.buttons:
                    if btn.rect.collidepoint(ev.pos):
                        btn.action()
                        return
                if self.slider.inflate(16, 24).collidepoint(ev.pos):
                    self.slider_drag = True
                    self.set_power_from_slider(ev.pos[0])
                    return
            if self.show_table:
                self.show_table = False
                return
            t = self.grid_tile(ev.pos)
            if t:
                self.click_grid(t, ev.button)
        elif ev.type == pygame.MOUSEMOTION:
            self.hover = self.grid_tile(ev.pos)
            if self.slider_drag:
                self.set_power_from_slider(ev.pos[0])
            elif self.dragging and self.hover and self.hover != self.drag_last and self.tool == "road":
                self.road_drag_to(self.hover)
        elif ev.type == pygame.MOUSEBUTTONUP:
            self.dragging = False
            self.slider_drag = False
        elif ev.type == pygame.KEYDOWN:
            keys = {pygame.K_r: "road", pygame.K_a: "A", pygame.K_c: "C",
                    pygame.K_m: "M", pygame.K_f: "F", pygame.K_e: "erase"}
            if ev.key in keys:
                self.set_tool(keys[ev.key])
            elif ev.key == pygame.K_LEFT:
                self.change_power(-1)
            elif ev.key == pygame.K_RIGHT:
                self.change_power(1)
            elif ev.key == pygame.K_SPACE:
                self.toggle_battle()
            elif ev.key == pygame.K_t:
                self.toggle_table()
            elif ev.key == pygame.K_ESCAPE:
                self.show_table = False

    # ---------------- drawing ----------------
    def text(self, surf, s, pos, font="m", color=INK, center=False, right=False):
        img = self.fonts[font].render(s, True, color)
        r = img.get_rect()
        if center:
            r.center = pos
        elif right:
            r.topright = pos
        else:
            r.topleft = pos
        surf.blit(img, r)
        return r

    def header(self, surf, label, y, color=HEADER):
        img = self.fonts["s"].render(label, True, INK)
        r = pygame.Rect(PX, y, img.get_width() + 18, 22)
        pygame.draw.rect(surf, color, r, border_radius=6)
        pygame.draw.rect(surf, INK, r, 2, border_radius=6)
        surf.blit(img, (r.x + 9, r.y + 4))

    def check_icon(self, surf, ok, pos, label):
        x, y = pos
        pygame.draw.circle(surf, GOOD if ok else BAD, (x + 8, y + 8), 8)
        if ok:
            pygame.draw.lines(surf, (255, 255, 255), False, [(x + 4, y + 8), (x + 7, y + 11), (x + 12, y + 5)], 2)
        else:
            pygame.draw.line(surf, (255, 255, 255), (x + 5, y + 5), (x + 11, y + 11), 2)
            pygame.draw.line(surf, (255, 255, 255), (x + 11, y + 5), (x + 5, y + 11), 2)
        r = self.text(surf, label, (x + 22, y + 1), "s")
        return r.right + 14

    def draw_button(self, surf, b):
        on = b.active()
        base = b.color or (255, 255, 255)
        fill = base if on else (255, 255, 255)
        if b.color is None and on:
            fill = HEADER
        pygame.draw.rect(surf, fill, b.rect, border_radius=8)
        pygame.draw.rect(surf, INK, b.rect, 2, border_radius=8)
        col = (255, 255, 255) if (on and b.color) else INK
        label = b.label
        if label == "Start battle" and self.battle_running():
            label = "Stop"
        self.text(surf, label, b.rect.center, b.font, col, center=True)

    def draw_grid(self, surf):
        pygame.draw.rect(surf, GRASS, (GX, GY, GRID_W, GRID_H))
        pygame.draw.rect(surf, START, (GX, GY, TILE, GRID_H))
        for c in range(COLS + 1):
            pygame.draw.line(surf, GRASS_LINE, (GX + c * TILE, GY), (GX + c * TILE, GY + GRID_H))
        for r in range(ROWS + 1):
            pygame.draw.line(surf, GRASS_LINE, (GX, GY + r * TILE), (GX + GRID_W, GY + r * TILE))
        for c in range(1, COLS + 1):
            self.text(surf, str(c), (GX + (c - 0.5) * TILE, GY - 9), "xs", MUTED, center=True)
        for r in range(1, ROWS + 1):
            self.text(surf, str(r), (GX - 6, GY + (r - 1) * TILE + 11), "xs", MUTED, right=True)
        for t in ROCKS:
            rr = tile_rect(t).inflate(-6, -6)
            pygame.draw.rect(surf, ROCK, rr, border_radius=6)
            pygame.draw.rect(surf, ROCK_DARK, rr, 2, border_radius=6)
            cx, cy = rr.center
            pygame.draw.polygon(surf, (225, 222, 216), [(cx - 8, cy + 6), (cx - 1, cy - 7), (cx + 8, cy + 6)])
            pygame.draw.polygon(surf, ROCK_DARK, [(cx - 8, cy + 6), (cx - 1, cy - 7), (cx + 8, cy + 6)], 2)
        self.draw_castle(surf)
        pygame.draw.rect(surf, INK, (GX, GY, GRID_W, GRID_H), 2)

    def draw_castle(self, surf):
        r = pygame.Rect(GX + 22 * TILE, GY + 7 * TILE, 2 * TILE, 3 * TILE)
        pygame.draw.rect(surf, (255, 255, 255), r)
        wall = pygame.Rect(r.x + 10, r.y + 46, r.w - 20, r.h - 54)
        stone, dark, roof = (214, 206, 192), (90, 80, 70), (214, 72, 52)
        pygame.draw.rect(surf, stone, wall)
        pygame.draw.rect(surf, dark, wall, 2)
        for tx in (r.x + 8, r.right - 24):
            tw = pygame.Rect(tx, r.y + 30, 16, r.h - 38)
            pygame.draw.rect(surf, stone, tw)
            pygame.draw.rect(surf, dark, tw, 2)
            pygame.draw.polygon(surf, roof, [(tx - 3, r.y + 31), (tx + 8, r.y + 8), (tx + 19, r.y + 31)])
            pygame.draw.polygon(surf, dark, [(tx - 3, r.y + 31), (tx + 8, r.y + 8), (tx + 19, r.y + 31)], 2)
        door = pygame.Rect(wall.centerx - 8, wall.bottom - 22, 16, 22)
        pygame.draw.rect(surf, (120, 80, 50), door, border_top_left_radius=8, border_top_right_radius=8)
        pygame.draw.rect(surf, INK, r, 2)

    def draw_boxes(self, surf):
        layer = pygame.Surface((W, H), pygame.SRCALPHA)
        clip = pygame.Rect(GX, GY, GRID_W, GRID_H)
        for pos, (k, n) in self.towers.items():
            box = pygame.Rect(GX + (pos[0] - 3) * TILE, GY + (pos[1] - 3) * TILE, 5 * TILE, 5 * TILE).clip(clip)
            pygame.draw.rect(layer, TOWERS[k]["color"] + (34,), box)
        if self.frost:
            pos = self.frost
            box = pygame.Rect(GX + (pos[0] - 3) * TILE, GY + (pos[1] - 3) * TILE, 5 * TILE, 5 * TILE).clip(clip)
            pygame.draw.rect(layer, FROST_COLOR + (40,), box)
        surf.blit(layer, (0, 0))
        for pos, (k, n) in self.towers.items():
            box = pygame.Rect(GX + (pos[0] - 3) * TILE, GY + (pos[1] - 3) * TILE, 5 * TILE, 5 * TILE).clip(clip)
            dashed_rect(surf, TOWERS[k]["color"], box)
        if self.frost:
            pos = self.frost
            box = pygame.Rect(GX + (pos[0] - 3) * TILE, GY + (pos[1] - 3) * TILE, 5 * TILE, 5 * TILE).clip(clip)
            dashed_rect(surf, FROST_COLOR, box)

    def draw_road(self, surf):
        tiles = self.analysis["tiles"]
        for i, info in enumerate(tiles):
            t = info["tile"]
            rr = tile_rect(t)
            pygame.draw.rect(surf, ROAD, rr)
            pygame.draw.rect(surf, ROAD_EDGE, rr, 1)
        for i, info in enumerate(tiles):
            t = info["tile"]
            rr = tile_rect(t)
            # small arrow at the edge the monster leaves through
            if i + 1 < len(tiles):
                nxt = tiles[i + 1]["tile"]
            elif self.road_complete():
                nxt = self.castle_entry
            else:
                nxt = None
            if nxt:
                dx, dy = nxt[0] - t[0], nxt[1] - t[1]
                cx, cy = rr.centerx + dx * 12, rr.centery + dy * 12
                px, py = -dy, dx
                pts = [(cx + dx * 4, cy + dy * 4), (cx - dx * 3 + px * 5, cy - dy * 3 + py * 5),
                       (cx - dx * 3 - px * 5, cy - dy * 3 - py * 5)]
                pygame.draw.polygon(surf, ROAD_EDGE, pts)
        drawn = set()
        for info in tiles:                      # tags, stars and overlap badges: once per tile
            t = info["tile"]
            if t in drawn:
                continue
            drawn.add(t)
            rr = tile_rect(t)
            if self.show_math and info["tag"]:
                tag = info["tag"]
                if len(tag) <= 3:
                    self.text(surf, tag, rr.center, "tag", INK, center=True)
                elif len(tag) == 4:
                    self.text(surf, tag, rr.center, "tiny", INK, center=True)
                else:                           # lots of towers: stack it as 3A / C / 4M
                    parts = short_tag(tag).split()
                    for j, part in enumerate(parts):
                        cy = rr.centery + (j - (len(parts) - 1) / 2) * 10
                        self.text(surf, part, (rr.centerx, cy), "tiny", INK, center=True)
            if self.show_math and info["frost"] and info["tag"]:
                draw_star(surf, FROST_COLOR, (rr.x + 7, rr.y + 7), 6)
            n = self.analysis["visits"].get(t, 1)
            if n > 1:
                badge = pygame.Rect(rr.right - 17, rr.bottom - 13, 16, 12)
                pygame.draw.rect(surf, WARN, badge, border_radius=3)
                self.text(surf, f"×{n}", badge.center, "xs", (255, 255, 255), center=True)
            if t in self.analysis["too_many"]:
                pygame.draw.rect(surf, BAD, rr, 3)
        if self.road and not self.road_complete():
            pygame.draw.rect(surf, INK, tile_rect(self.road[-1]), 2)
            if self.touches_castle():           # invite the student to click the castle
                castle = pygame.Rect(GX + 22 * TILE, GY + 7 * TILE, 2 * TILE, 3 * TILE)
                dashed_rect(surf, GOOD, castle.inflate(-4, -4), 3, 8)
        elif self.road_complete():
            e, last = tile_rect(self.castle_entry), tile_rect(self.road[-1])
            dx, dy = (e.centerx - last.centerx) // TILE, (e.centery - last.centery) // TILE
            gate = pygame.Rect(0, 0, 14, 14)
            gate.center = (last.centerx + dx * 25, last.centery + dy * 25)   # just inside the castle
            pygame.draw.rect(surf, ROAD, gate)          # the road runs into the castle here
            pygame.draw.rect(surf, GOOD, gate, 2)

    def draw_towers(self, surf):
        for pos, (k, n) in self.towers.items():
            cx, cy = tile_center(pos)
            pygame.draw.circle(surf, TOWERS[k]["color"], (cx, cy), 14)
            pygame.draw.circle(surf, INK, (cx, cy), 14, 2)
            self.text(surf, f"{k}{n}", (cx, cy + 1), "s", (255, 255, 255), center=True)
        if self.frost:
            cx, cy = tile_center(self.frost)
            pygame.draw.circle(surf, FROST_COLOR, (cx, cy), 14)
            pygame.draw.circle(surf, INK, (cx, cy), 14, 2)
            self.text(surf, "F", (cx, cy + 1), "s", (255, 255, 255), center=True)

    def draw_hover(self, surf):
        t = self.hover
        if not t or self.battle_running() or self.show_table:
            return
        if (self.tool in TOWERS or self.tool == "F") and t not in ROCKS and t not in CASTLE \
                and t not in self.road and t not in self.towers and t != self.frost:
            color = FROST_COLOR if self.tool == "F" else TOWERS[self.tool]["color"]
            box = pygame.Rect(GX + (t[0] - 3) * TILE, GY + (t[1] - 3) * TILE, 5 * TILE, 5 * TILE)
            dashed_rect(surf, color, box.clip((GX, GY, GRID_W, GRID_H)), 1, 4)
            pygame.draw.circle(surf, color, tile_center(t), 14, 2)
        else:
            pygame.draw.rect(surf, INK, tile_rect(t), 1)

    def draw_monster(self, surf):
        b = self.battle
        if not b:
            return
        if b["idx"] >= len(self.road):
            if b["result"] == "escaped":
                return
            cur = self.road[-1]
        else:
            cur = self.road[b["idx"]] if b["idx"] >= 0 else (0, self.road[0][1])
        prev = b["prev_pos"]
        # glide during the first 0.3 s of each second, then sit while the towers fire
        f = 1.0 if b["result"] else min(1.0, b["timer"] / 0.3)
        a = tile_center(prev) if prev[0] >= 1 else (GX - TILE * 0.5, GY + (prev[1] - 0.5) * TILE)
        c = tile_center(cur) if cur[0] >= 1 else (GX - TILE * 0.5, GY + (cur[1] - 0.5) * TILE)
        x = a[0] + (c[0] - a[0]) * f
        y = a[1] + (c[1] - a[1]) * f
        if b["result"] == "defeated":
            self.text(surf, "DEFEATED", (x, y - 26), "s", BAD, center=True)
            pygame.draw.circle(surf, (255, 255, 255), (x, y), 10)
            pygame.draw.circle(surf, MUTED, (x, y), 10, 2)
            return
        frozen = (b["result"] is None and 0 <= b["idx"] < len(self.road)
                  and b["turn"] == 2)
        if frozen:                                  # icy block behind the monster while Frost holds it
            ice = pygame.Surface((40, 40), pygame.SRCALPHA)
            pygame.draw.rect(ice, FROST_COLOR + (90,), ice.get_rect(), border_radius=8)
            pygame.draw.rect(ice, (225, 242, 252, 230), ice.get_rect(), 2, border_radius=8)
            surf.blit(ice, (x - 20, y - 20))
        self.paint_monster(surf, b["monster"]["key"], x, y)
        if frozen:
            img = self.fonts["xs"].render("FROZEN", True, (255, 255, 255))
            pill = img.get_rect(center=(x, y + 25)).inflate(8, 4)
            pygame.draw.rect(surf, FROST_COLOR, pill, border_radius=5)
            surf.blit(img, img.get_rect(center=pill.center))
        if b["hp"] is not None:
            bar = pygame.Rect(x - 20, y - 26, 40, 6)
            pygame.draw.rect(surf, (255, 255, 255), bar)
            frac = float(b["hp"] / b["max_hp"]) if b["max_hp"] else 0
            pygame.draw.rect(surf, GOOD if frac > 0.3 else BAD, (bar.x, bar.y, bar.w * frac, bar.h))
            pygame.draw.rect(surf, INK, bar, 1)

    def paint_monster(self, surf, key, x, y):
        if key == "dummy":
            pygame.draw.line(surf, (140, 100, 60), (x, y), (x, y + 15), 4)
            for rad, col in ((13, (240, 228, 190)), (9, BAD), (5, (240, 228, 190)), (2, BAD)):
                pygame.draw.circle(surf, col, (x, y - 2), rad)
            pygame.draw.circle(surf, INK, (x, y - 2), 13, 2)
        elif key == "slime":
            body = pygame.Rect(x - 14, y - 12, 28, 26)
            pygame.draw.ellipse(surf, (110, 200, 80), body)
            pygame.draw.rect(surf, (110, 200, 80), (x - 14, y + 2, 28, 10))
            pygame.draw.ellipse(surf, INK, body, 2)
            for ex in (-5, 5):
                pygame.draw.circle(surf, (255, 255, 255), (x + ex, y - 1), 4)
                pygame.draw.circle(surf, INK, (x + ex, y - 1), 2)
        elif key == "knight":
            pygame.draw.polygon(surf, BAD, [(x - 2, y - 14), (x + 10, y - 20), (x + 6, y - 10)])
            helm = pygame.Rect(x - 12, y - 13, 24, 28)
            pygame.draw.rect(surf, (190, 196, 204), helm, border_radius=10)
            pygame.draw.rect(surf, INK, helm, 2, border_radius=10)
            for vy in (y - 2, y + 3, y + 8):
                pygame.draw.line(surf, INK, (x - 7, vy), (x + 7, vy), 2)
        elif key == "bats":
            for bx, by in ((-10, -6), (10, -6), (0, 6)):
                cx, cy = x + bx, y + by
                pygame.draw.polygon(surf, (110, 70, 170), [(cx - 11, cy - 4), (cx - 3, cy), (cx - 9, cy + 4)])
                pygame.draw.polygon(surf, (110, 70, 170), [(cx + 11, cy - 4), (cx + 3, cy), (cx + 9, cy + 4)])
                pygame.draw.circle(surf, (90, 50, 150), (cx, cy), 5)
                pygame.draw.circle(surf, (255, 255, 255), (cx - 2, cy - 1), 1)
                pygame.draw.circle(surf, (255, 255, 255), (cx + 2, cy - 1), 1)
        elif key == "mimic":
            lid = pygame.Rect(x - 15, y - 14, 30, 10)
            box = pygame.Rect(x - 15, y - 2, 30, 16)
            pygame.draw.rect(surf, (165, 105, 55), lid, border_top_left_radius=6, border_top_right_radius=6)
            pygame.draw.rect(surf, (165, 105, 55), box)
            pygame.draw.rect(surf, (60, 20, 20), (x - 13, y - 4, 26, 4))
            for tx in range(-12, 13, 6):
                pygame.draw.polygon(surf, (255, 255, 255), [(x + tx, y - 4), (x + tx + 3, y + 1), (x + tx + 6, y - 4)])
            pygame.draw.ellipse(surf, BAD, (x - 4, y - 1, 10, 8))
            pygame.draw.rect(surf, INK, lid, 2, border_top_left_radius=6, border_top_right_radius=6)
            pygame.draw.rect(surf, INK, box, 2)
            pygame.draw.circle(surf, (240, 200, 60), (x, y + 7), 3)

    def draw_effects(self, surf):
        for e in self.effects:
            k = e["t"] / e["life"]
            if e["kind"] == "shot":
                pygame.draw.line(surf, e["color"], e["from"], e["to"], max(1, int(4 * (1 - k))))
            else:
                x, y = e["pos"]
                img = self.fonts["s"].render(e["text"], True, e["color"])
                img.set_alpha(int(255 * (1 - k)))
                r = img.get_rect(center=(x + e["dx"], y - 38 + e.get("dy", 0) - 26 * k))
                pygame.draw.rect(surf, (255, 255, 255), r.inflate(4, 2), border_radius=4)
                surf.blit(img, r)

    def draw_table(self, surf):
        a = self.analysis
        rows = a["table"]
        r = pygame.Rect(GX + 20, GY + 20, GRID_W - 40, GRID_H - 40)
        pygame.draw.rect(surf, PANEL, r, border_radius=12)
        pygame.draw.rect(surf, INK, r, 2, border_radius=12)
        self.text(surf, "TAG TABLE   (click anywhere or press Esc to close)", (r.x + 16, r.y + 12), "m")
        frows = a["frost_table"] if self.frost else []
        # shrink the rows when the Frost section needs room
        lines = len(rows) + (len(frows) + 3 if self.frost else 0)
        rh = max(17, min(26, (r.h - 44 - 28 - 50) // max(1, lines)))
        max_rows = max(4, (r.h - 122 - ((len(frows) + 3) * rh if self.frost else 0)) // rh)
        fit = lambda tag: tag if self.fonts["s"].size(tag)[0] <= 70 else short_tag(tag)
        cols = [("Tag", 16), ("How many?", 90), ("Each tower's damage on one tile", 190),
                ("COMBINED", 440), ("Damage on ALL those tiles", 560)]
        y = r.y + 44
        pygame.draw.rect(surf, HEADER, (r.x + 10, y - 4, r.w - 20, 26))
        for label, cx in cols:
            self.text(surf, label, (r.x + cx, y), "s")
        y += 28
        for row in rows[:max_rows]:
            allc, allk = row["coef"] * row["count"], row["const"] * row["count"]
            vals = [fit(row["tag"]), str(row["count"]), row["each"], expr_str(row["coef"], row["const"]),
                    f"{row['count']}({expr_str(row['coef'], row['const'])}) = {expr_str(allc, allk)}"]
            for (label, cx), v in zip(cols, vals):
                self.text(surf, v, (r.x + cx, y), "s")
            pygame.draw.line(surf, GRASS_LINE, (r.x + 10, y + rh - 4), (r.right - 10, y + rh - 4))
            y += rh
        if len(rows) > max_rows:
            self.text(surf, f"... and {len(rows) - max_rows} more tags", (r.x + 16, y), "s", MUTED)
            y += rh
        if not rows:
            self.text(surf, "No road tiles are inside a tower box yet.", (r.x + 16, y), "s", MUTED)
            y += rh
        if self.frost:
            y += 6
            fcols = [("Tag on", 16), ("Damage per tag", 130), ("Star tiles", 300),
                     ("Extra damage = damage per tag × star tiles", 420)]
            pygame.draw.rect(surf, (200, 228, 245), (r.x + 10, y - 4, r.w - 20, 26))
            for label, cx in fcols:
                self.text(surf, label, (r.x + cx, y), "s")
            draw_star(surf, FROST_COLOR, (r.x + 74, y + 7), 7)
            y += 28
            for row in frows:
                d = expr_str(row["coef"], row["const"])
                ec, ek = row["coef"] * row["count"], row["const"] * row["count"]
                dd = f"({d})" if "+" in d else d
                vals = [fit(row["tag"]), d, str(row["count"]), f"{dd} × {row['count']} = {expr_str(ec, ek)}"]
                for (label, cx), v in zip(fcols, vals):
                    self.text(surf, v, (r.x + cx, y), "s")
                pygame.draw.line(surf, GRASS_LINE, (r.x + 10, y + rh - 4), (r.right - 10, y + rh - 4))
                y += rh
            if not frows:
                self.text(surf, "No tagged road tiles are inside the Frost box.", (r.x + 16, y), "s", MUTED)
        T = a["T"]
        if self.frost:
            self.text(surf, f"T = {expr_str(*T)}   + Extra {expr_str(*a['extra'])}   "
                            f"= T after Patch {expr_str(*a['T_after'])}", (r.x + 16, r.bottom - 36), "m", BAD)
        else:
            self.text(surf, f"TOTAL  T = {expr_str(*T)}", (r.x + 16, r.bottom - 38), "l", BAD)

    def draw_panel(self, surf):
        a = self.analysis
        y = 76
        self.header(surf, "YOUR LEVEL", y)
        y += 30
        if not self.road:
            road_txt = "Road: not started"
        elif self.road_complete():
            road_txt = f"Road: {len(self.road)} tiles, reaches the castle"
        elif self.touches_castle():
            road_txt = f"Road: {len(self.road)} tiles, click the castle to connect"
        else:
            road_txt = f"Road: {len(self.road)} tiles, not at the castle yet"
        extra_visits = len(self.road) - len(a["visits"])
        if extra_visits:
            road_txt += f" ({extra_visits} overlap)"
        self.text(surf, road_txt, (PX, y), "m", GOOD if self.road_complete() else INK)
        y += 26
        x = PX
        for k in ORDER:
            n = a["counts"][k]
            x = self.text(surf, f"{TOWERS[k]['name']} {n}", (x, y), "m", TOWERS[k]["color"]).right + 16
        total = sum(a["counts"].values())
        self.text(surf, f"Total {total}", (x, y), "m")
        y += 28
        x = PX
        x = self.check_icon(surf, all(2 <= n <= 3 for n in a["counts"].values()), (x, y), "2-3 of each")
        x = self.check_icon(surf, 6 <= total <= 9, (x, y), "6-9 towers")
        self.check_icon(surf, not a["too_many"], (x, y), "max 3 boxes per tile")
        y += 30
        if self.show_math:
            self.text(surf, f"Overlap types: {len(a['overlaps'])}   ({a['level']})", (PX, y), "m")
            y += 24
            line, lines = "", []
            for tag in a["overlaps"]:
                if len(line) + len(tag) + 2 > 40:
                    lines.append(line)
                    line = ""
                line += tag + "  "
            if line:
                lines.append(line)
            for ln in lines[:2]:
                self.text(surf, ln, (PX + 8, y), "s", MUTED)
                y += 20
            if not lines:
                self.text(surf, "(none yet)", (PX + 8, y), "s", MUTED)
                y += 20
        else:
            self.text(surf, "Overlap types: hidden", (PX, y), "m", MUTED)
            y += 44
        y = min(max(y, 238) + 4, 252)
        x = self.check_icon(surf, a["same"] and self.show_math, (PX, y), "same-tower (AA, CC, MM)")
        self.check_icon(surf, a["three"] and self.show_math, (x, y), "3-letter (AAC, ACM)")

        y = 272
        self.header(surf, "TOTAL DAMAGE ON YOUR ROAD", y, (255, 190, 160))
        b = self.battle
        reveal = self.show_math or (b is not None and b["result"] is not None)
        if self.frost:
            T = expr_str(*a["T_after"]) if reveal else "?"
            self.text(surf, f"T after Frost = {T}", (PX, y + 28), "l", BAD)
            sub = (f"= Day 2 T ({expr_str(*a['T'])}) + Frost extra ({expr_str(*a['extra'])})"
                   if reveal else "= Day 2 T + Frost extra")
            self.text(surf, sub, (PX, y + 50), "xs", FROST_COLOR)
        else:
            T = expr_str(*a["T"]) if reveal else "?"
            self.text(surf, f"T = {T}", (PX, y + 32), "xl", BAD)

        y = 336
        self.header(surf, "BATTLE", y, (170, 225, 210))
        self.text(surf, "Power x", (PX, 368), "m")
        pygame.draw.rect(surf, (220, 214, 200), self.slider, border_radius=3)
        kx = self.slider.left + self.slider.width * self.power / 100
        pygame.draw.circle(surf, INK, (kx, self.slider.centery), 9)
        self.text(surf, str(self.power), (PX + 372, 366), "l")
        m = MONSTERS[self.monster_i]
        self.text(surf, "Monster", (PX, 410), "m")
        self.text(surf, m["name"], (PX + 222, 419), "m", center=True)
        hp_txt = m["desc"]
        if m["key"] == "mimic":
            hp_txt += f"  At x = {self.power}: {10 * self.power + 1500} HP."
        self.text(surf, hp_txt, (PX, 442), "xs", MUTED)
        self.text(surf, "Speed", (PX, 472), "m")
        for btn in self.buttons:
            if btn.rect.top >= 330:
                self.draw_button(surf, btn)

        y = 510
        pygame.draw.line(surf, GRASS_LINE, (PX, y), (PX + PW - 20, y), 2)
        y += 10
        if not b:
            self.text(surf, "Press Start battle (or Space).", (PX, y), "s", MUTED)
            self.text(surf, "Each second the monster moves 1 tile and", (PX, y + 24), "s", MUTED)
            self.text(surf, "every tower in range hits it once.", (PX, y + 44), "s", MUTED)
            return
        n = len(self.road)
        shown = min(b["idx"] + 1, n)
        last = b["last"]
        self.text(surf, f"Road tile {shown} of {n}" + (f"    Tag: {last['tag'] or '(none)'}" if last else ""),
                  (PX, y), "m")
        y += 26
        if last:
            if last["hits"]:
                each = each_str(last["tag"])
                val = last["coef"] * b["x"] + last["const"]
                line = f"This tile: {each}"
                if len(last["hits"]) > 1:
                    line += f" = {expr_str(last['coef'], last['const'])}"
                self.text(surf, line, (PX, y), "s")
                self.text(surf, f"   = {frac_str(val)} damage at x = {frac_str(b['x'])}", (PX, y + 20), "s")
                if b["turn"] == 2:
                    self.text(surf, "Frozen: hit again", (PX + 250, y + 20), "s", FROST_COLOR)
            elif last["frost"]:
                self.text(surf, "This tile: no tower reaches it (0 damage)", (PX, y), "s", MUTED)
                if b["turn"] == 2:
                    self.text(surf, "Frozen: hit again", (PX + 250, y + 20), "s", FROST_COLOR)
            else:
                self.text(surf, "This tile: no tower reaches it (0 damage)", (PX, y), "s", MUTED)
        y += 46
        self.text(surf, "Total damage so far:", (PX, y), "s")
        self.text(surf, f"{expr_str(b['coef'], b['const'])} = {frac_str(b['raw'])}", (PX, y + 20), "l", BAD)
        y += 52
        if b["hp"] is not None:
            mm = b["monster"]
            each = " each" if mm["key"] == "bats" else ""
            self.text(surf, f"{mm['name']} HP{each}: {frac_str(b['hp'])} / {frac_str(b['max_hp'])}", (PX, y), "s")
            bar = pygame.Rect(PX + 250, y + 2, 130, 12)
            pygame.draw.rect(surf, (235, 230, 220), bar)
            frac = float(b["hp"] / b["max_hp"]) if b["max_hp"] else 0
            pygame.draw.rect(surf, GOOD if frac > 0.3 else BAD, (bar.x, bar.y, bar.w * frac, bar.h))
            pygame.draw.rect(surf, INK, bar, 1)

    def draw(self, surf):
        surf.fill(BG)
        self.text(surf, "TOWER DEFENSE", (GX, 14), "l", (30, 120, 110))
        self.text(surf, "DESIGNER", (GX, 38), "l", INK)
        self.text(surf, "Math 9 · Mr. Chung", (GX + 150, 44), "xs", MUTED)
        for btn in self.buttons:
            if btn.rect.top < 330:
                self.draw_button(surf, btn)
        self.draw_grid(surf)
        if self.show_boxes:
            self.draw_boxes(surf)
        self.draw_road(surf)
        self.draw_towers(surf)
        self.draw_hover(surf)
        self.draw_monster(surf)
        self.draw_effects(surf)
        if self.show_table:
            self.draw_table(surf)
        self.draw_panel(surf)
        # message bar
        self.text(surf, self.message, (GX, GY + GRID_H + 14), "m", self.msg_color)
        self.text(surf, "Keys: R A C M F E = tools   Right-click = erase   Left/Right = power   "
                        "Space = battle   T = tag table", (GX, GY + GRID_H + 40), "xs", MUTED)


async def main():
    pygame.init()
    pygame.display.set_caption("Tower Defense Designer - Math 9")
    screen = pygame.display.set_mode((W, H))
    clock = pygame.time.Clock()
    game = Game()
    running = True
    while running:
        dt = clock.tick(60) / 1000
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                running = False
            else:
                game.handle(ev)
        game.update(dt)
        game.draw(screen)
        pygame.display.flip()
        await asyncio.sleep(0)          # lets the game run in a browser (pygbag)
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
